scale = [-50, 900, 0, 400];
rholims = [0,3];
phalims = [0,90];
VE = 1.;