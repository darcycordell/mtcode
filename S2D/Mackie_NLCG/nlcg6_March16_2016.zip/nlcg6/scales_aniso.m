% y
%scale(1)=-100;
%scale(2)=350;
zfix=60 ; %depth to calculate the conductance from surface in km
scale(3)=-5;
scale(4)=60;
% rho
rholims=[1 3];
% ph
phalims=[0 90];
% vertical exaggeration
VE=1;
max_p=200 %maximum profile lenght possible in km
max_d=200 % maximum depth of the profile possible in km
