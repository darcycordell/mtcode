function [Z,Zvar,T,Tvar,Rhoa,Rhoaerr,Phs,Phserr,f,zrot,rhorot,trot,coords] = read_edi_dr(filename)
%
%[Z,Zvar,T,Tvar,Rhoa,Phs,f,rot,coords] = load_edi(filename)
%
%    load_edi(filename) reads in an edi file and puts
%    out the impedance tensor Z, its variance Zvar as
%    2x2xN arrays, the tipper T, its variance Tvar as
%    1x2xN arrays, the apparent resistivity Rhoa and
%    the Phase Phs as  2x2xN arrays, the frequencies
%    as a vector of legth N, the coordinates as a
%    vector of length 3, with coords=[lat; long; elev]
%    and rot the rotation angle of the impedance data.

%    This version has reading of lat/long/elev added (March 1 2012)

% Reading in edi file
fid=fopen(filename,'rt');
while 1
    tline = fgetl(fid);
    if ~ischar(tline), break, end
    if strncmp(strtrim(tline),'EMPTY=',6)
        [tmp,empty_str]=strtok(tline,'=');
        ind=findstr(empty_str,'=');
        empty_str(ind)=[];
        empty=str2num(empty_str);
    end
    if strncmp(strtrim(tline),'LAT=',4)
        tline=strtrim(tline);
        lat=tline(5:length(tline));
    end
    if strncmp(strtrim(tline),'LONG=',5)
        tline=strtrim(tline);
        long=tline(6:length(tline));
    end
    if strncmp(strtrim(tline),'ELEV=',5)
        [tmp,tline]=strtok(tline,'=');
        ind=strfind(tline,'=');
        tline(ind)=[];
        elev=str2num(tline);
    end
    if strncmp(strtrim(tline),'REFLAT=',7)
        tline=strtrim(tline);
        reflat=tline(8:length(tline));
    end
    if strncmp(strtrim(tline),'REFLONG=',8)
        tline=strtrim(tline);
        reflong=tline(9:length(tline));
    end
    if strncmp(strtrim(tline),'REFELEV=',8)
        [tmp,tline]=strtok(tline,'=');
        ind=strfind(tline,'=');
        tline(ind)=[];
        refelev=str2num(tline);
    end
    if strncmp(tline,'>FREQ',5)
        nfreq=find_nfreq(tline);
        f(:,1)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZROT',5)
        nfreq=find_nfreq(tline);
        zrot=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXXR',5)
        nfreq=find_nfreq(tline);
        zxxr=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXXI',5)
        nfreq=find_nfreq(tline);
        zxxi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXX.VAR',8)
        nfreq=find_nfreq(tline);
        Zvar(1,1,1:nfreq)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXYR',5)
        nfreq=find_nfreq(tline);
        ind1=strfind(tline,'ROT='); %Now make sure the impedance rotation is defined properly
        if ~isempty(ind1)
            ind1=ind1+4;
            ind2=strfind(tline,'//')-2;
            if strcmp(tline(ind1:ind2),'NORTH')
                zrot=zeros(nfreq); %if the rotation is north, then zrot=0
            elseif strcmp(tline(ind1:ind2),'ZROT')
                %don't do anything because ZROT should already be defined
                if ~exist('zrot','var')
                    error('zrot dosn''t appear to be defined, but is used!')
                end
            else
                error('The impedance rotation is undefined')
            end
        else
            warning('Not sure if the impedance rotation is defined properly!')
        end
        zxyr=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXYI',5)
        nfreq=find_nfreq(tline);
        zxyi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZXY.VAR',8)
        nfreq=find_nfreq(tline);
        Zvar(1,2,1:nfreq)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYXR',5)
        nfreq=find_nfreq(tline);
        zyxr=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYXI',5)
        nfreq=find_nfreq(tline);
        zyxi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYX.VAR',8)
        nfreq=find_nfreq(tline);
        Zvar(2,1,1:nfreq)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYYR',5)
        nfreq=find_nfreq(tline);
        zyyr=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYYI',5)
        nfreq=find_nfreq(tline);
        zyyi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>ZYY.VAR',8)
        nfreq=find_nfreq(tline);
        Zvar(2,2,1:nfreq)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TROT.EXP',9)
        nfreq=find_nfreq(tline);
        trot=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TXR.EXP',8)
        nfreq=find_nfreq(tline);
        ind1=strfind(tline,'ROT='); %Now make sure the impedance rotation is defined properly
        if ~isempty(ind1)
            ind1=ind1+4;
            ind2=strfind(tline,'//')-2;
            if strcmp(tline(ind1:ind2),'NORTH')
                if exist('trot','var')
                    if all(trot ~= 0)
                        error('trot is defined as something other than zero, but ROT=NORTH.....nonsense!')
                    end
                else
                    trot=zeros(nfreq); %if the rotation is north, then zrot=0
                end
            elseif strcmp(tline(ind1:ind2),'TROT')
                %don't do anything because TROT should already be defined
                if ~exist('trot','var')
                    error('trot dosn''t appear to be defined, but is used!')
                end
            else
                error('Tipper rotation is undefined (ROT= does not match expected values)')
            end
        else %if it doesn't say what the rotation is at all
            if ~exist('trot','var') %check if trot exists, if not, there is a problem
                warning('Tipper rotation is undefined, assumed to be the same as impedance')
                trot=zrot;
            end
        end
        txr=fscanf(fid,'%f',nfreq);% read in the data
    end
    if strncmp(tline,'>TXI.EXP',8)
        nfreq=find_nfreq(tline);
        txi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TXVAR.EXP',10)
        nfreq=find_nfreq(tline);
        Tvar(1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TYR.EXP',8)
        nfreq=find_nfreq(tline);
        tyr=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TYI.EXP',8)
        nfreq=find_nfreq(tline);
        tyi=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>TYVAR.EXP',10)
        nfreq=find_nfreq(tline);
        Tvar(2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOROT',7)
        nfreq=find_nfreq(tline);
        rhorot=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOXX',6) && ~strncmp(tline,'>RHOXX.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoa(1,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOXX.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoaerr(1,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOXY',6)&& ~strncmp(tline,'>RHOXY.ERR',10)
        nfreq=find_nfreq(tline);
        ind1=strfind(tline,'ROT='); %Now make sure the impedance rotation is defined properly
        if ~isempty(ind1)
            ind1=ind1+4;
            ind2=strfind(tline,'//')-2;
            if strcmp(tline(ind1:ind2),'NORTH')
                if exist('rhorot','var')
                    if all(rhorot ~= 0)
                        error('rhorot is defined as something other than zero, but ROT=NORTH.....nonsense!')
                    end
                else
                    rhorot=zeros(nfreq); %if the rotation is north, then rhorot=0
                end
            elseif strcmp(tline(ind1:ind2),'RHOROT')
                %don't do anything because ZROT should already be defined
                if ~exist('rhorot','var')
                    error('rhorot dosn''t appear to be defined, but is used!')
                end
            else
                error('The resistivity/phase rotation is undefined')
            end
        else%if it doesn't say what the rotation is at all
            if ~exist('rhorot','var') %check if rhorot exists, if not, there is a problem
                error('Resistivity/Phase rotation is undefined')
            end
        end
        Rhoa(1,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOXY.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoaerr(1,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOYX',6) && ~strncmp(tline,'>RHOYX.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoa(2,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOYX.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoaerr(2,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOYY',6) && ~strncmp(tline,'>RHOYY.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoa(2,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>RHOYY.ERR',10)
        nfreq=find_nfreq(tline);
        Rhoaerr(2,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSXX',6) && ~strncmp(tline,'>PHSXX.ERR',10)
        nfreq=find_nfreq(tline);
        Phs(1,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSXX.ERR',10)
        nfreq=find_nfreq(tline);
        Phserr(1,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSXY',6) && ~strncmp(tline,'>PHSXY.ERR',10)
        nfreq=find_nfreq(tline);
        Phs(1,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSXY.ERR',10)
        nfreq=find_nfreq(tline);
        Phserr(1,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSYX',6) && ~strncmp(tline,'>PHSYX.ERR',10)
        nfreq=find_nfreq(tline);
        Phs(2,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSYX.ERR',10)
        nfreq=find_nfreq(tline);
        Phserr(2,1,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSYY',6) && ~strncmp(tline,'>PHSYY.ERR',10)
        nfreq=find_nfreq(tline);
        Phs(2,2,:)=fscanf(fid,'%f',nfreq);
    end
    if strncmp(tline,'>PHSYY.ERR',10)
        nfreq=find_nfreq(tline);
        Phserr(2,2,:)=fscanf(fid,'%f',nfreq);
    end
end
fclose(fid);
% Creating data array
% Coordinates
if exist('lat','var')
    if lat(1)=='-'; latsign=-1; else latsign=1; end;
    lat=regexprep(lat,':',' ');
    lat=sscanf(lat,'%f');
end;
if exist('long','var')
    if long(1)=='-'; longsign=-1; else longsign=1; end;
    long=regexprep(long,':',' ');
    long=sscanf(long,'%f');
end;
if ~exist('elev','var'); elev=0; end;
if exist('reflat','var')
    if reflat(1)=='-'; reflatsign=-1; else reflatsign=1; end;
    reflat=regexprep(reflat,':',' ');
    reflat=sscanf(reflat,'%f');
end;
if exist('reflong','var')
    if reflong(1)=='-'; reflongsign=-1; else reflongsign=1; end;
    reflong=regexprep(reflong,':',' ');
    reflong=sscanf(reflong,'%f');
end;
% Convert coordinates to decimal degrees
if exist('lat','var') && numel(lat)==3; lat=latsign*(abs(lat(1))+lat(2)/60+lat(3)/3600); end;
if exist('lat','var') && numel(lat)==2; lat=latsign*(abs(lat(1))+lat(2)/60); end;
if exist('long','var') && numel(long)==3; long=longsign*(abs(long(1))+long(2)/60+long(3)/3600); end;
if exist('long','var') && numel(long)==2; long=longsign*(abs(long(1))+long(2)/60); end;
if exist('reflat','var') && numel(reflat)==3; reflat=reflatsign*(abs(reflat(1))+reflat(2)/60+reflat(3)/3600); end;
if exist('reflat','var') && numel(reflat)==2; reflat=reflatsign*(abs(reflat(1))+reflat(2)/60); end;
if exist('reflong','var') && numel(reflong)==3; reflong=reflongsign*(abs(reflong(1))+reflong(2)/60+reflong(3)/3600); end;
if exist('reflong','var') && numel(reflong)==2; reflong=reflongsign*(abs(reflong(1))+reflong(2)/60); end;
% Coordinates
coords=zeros(3,1);
if exist('reflat','var'); coords(1)=reflat; end;
if exist('reflong','var'); coords(2)=reflong; end;
if exist('refelev','var'); coords(3)=refelev; end;
% lat, long, elev replace reflat, reflong, refelev when present
if exist('lat','var'); coords(1)=lat; end;
if exist('long','var'); coords(2)=long; end;
if exist('elev','var'); coords(3)=elev; end;
% Rotation angles
if ~exist('zrot','var'); zrot=NaN(nfreq);
elseif ~exist('rhorot','var'); rhorot=NaN(nfreq);
elseif ~exist('trot','var'); trot=NaN(nfreq);
end
% Impedances
Z=NaN(2,2,length(f))+1i.*NaN(2,2,length(f));
if exist('zxxr','var'); Z(1,1,1:length(zxxr))=zxxr+(1i.*zxxi); end;
if exist('zxyr','var'); Z(1,2,1:length(zxyr))=zxyr+(1i.*zxyi); end;
if exist('zyxr','var'); Z(2,1,1:length(zyxr))=zyxr+(1i.*zyxi); end;
if exist('zyyr','var'); Z(2,2,1:length(zyyr))=zyyr+(1i.*zyyi); end;
if ~exist('Zvar','var'); Zvar=zeros(2,2,length(f))+1i.*zeros(2,2,length(f)); end;
% Tipper
T=NaN(2,length(f));
if exist('txr','var'); T(1,:)=txr(1:length(f))+(1i.*txi(1:length(f))); end; % do not record any tipper values which have no frequency associated with them ... (ABT dataset!)
if exist('tyr','var'); T(2,:)=tyr(1:length(f))+(1i.*tyi(1:length(f))); end;
if ~exist('Tvar','var'); Tvar=NaN(2,length(f)); end;
if ~exist('T','var'); T=NaN(2,length(f))+1i.*NaN(2,length(f)); end;
% Apparent resistivities
if ~exist('Rhoa','var'); Rhoa=NaN(2,2,length(f)); end;
if ~exist('Rhoaerr','var'); Rhoaerr=NaN(2,2,length(f)); end;
% Phases
if ~exist('Phs','var'); Phs=NaN(2,2,length(f)); end;
if ~exist('Phserr','var'); Phserr=NaN(2,2,length(f)); end;
% remove empty data (make it NaN)
if exist('empty','var')
    if exist('Z','var')
        indxx=find(real(Z(1,1,:))==empty);% we assume that if the real part is non-existent, so is the imaginary part
        indxy=find(real(Z(1,2,:))==empty);
        indyx=find(real(Z(2,1,:))==empty);
        indyy=find(real(Z(2,2,:))==empty);
        Z(1,1,indxx)=NaN+1i*NaN;
        Zvar(1,1,indxx)=NaN+1i*NaN;
        Z(1,2,indxy)=NaN+1i*NaN;
        Zvar(1,2,indxy)=NaN+1i*NaN;
        Z(2,1,indyx)=NaN+1i*NaN;
        Zvar(2,1,indyx)=NaN+1i*NaN;
        Z(2,2,indyy)=NaN+1i*NaN;
        Zvar(2,2,indyy)=NaN+1i*NaN;
        if all(all(all(real(Z(:,:,:))==0))) %Now look to see if all the values are zero, in which case we assume there is no data
            Z(:,:,:)=NaN(2,2,nfreq)+1i*NaN(2,2,nfreq);
            Zvar(:,:,:)=NaN(2,2,nfreq)+1i*NaN(2,2,nfreq);
        end
    end
    if exist('Rhoa','var')
        indxx=find(Rhoa(1,1,:)==empty);
        indxy=find(Rhoa(1,2,:)==empty);
        indyx=find(Rhoa(2,1,:)==empty);
        indyy=find(Rhoa(2,2,:)==empty);
        Rhoa(1,1,indxx)=NaN;
        Rhoa(1,2,indxy)=NaN;
        Rhoa(2,1,indyx)=NaN;
        Rhoa(2,2,indyy)=NaN;
        Rhoaerr(1,1,indxx)=NaN;
        Rhoaerr(1,2,indxy)=NaN;
        Rhoaerr(2,1,indyx)=NaN;
        Rhoaerr(2,2,indyy)=NaN;
        if all(all(all(Rhoa(:,:,:)==0)))
            Rhoa(:,:,:)=NaN(2,2,nfreq);
            Rhoaerr(:,:,:)=NaN(2,2,nfreq);
        end
    end
    if exist('Phs','var')
        indxx=find(Phs(1,1,:)==empty);
        indxy=find(Phs(1,2,:)==empty);
        indyx=find(Phs(2,1,:)==empty);
        indyy=find(Phs(2,2,:)==empty);
        Phs(1,1,indxx)=NaN;
        Phs(1,2,indxy)=NaN;
        Phs(2,1,indyx)=NaN;
        Phs(2,2,indyy)=NaN;
        Phserr(1,1,indxx)=NaN;
        Phserr(1,2,indxy)=NaN;
        Phserr(2,1,indyx)=NaN;
        Phserr(2,2,indyy)=NaN;
        if all(all(all(Phs(:,:,:)==0)))
            Phs(:,:,:)=NaN(2,2,nfreq);
            Phserr(:,:,:)=NaN(2,2,nfreq);
        end
    end
    if exist('T','var')
        indx=find(real(T(1,:))==empty);
        indy=find(real(T(2,:))==empty);
        T(1,indx)=NaN+1i*NaN;
        T(2,indy)=NaN+1i*NaN;
        Tvar(1,indx)=NaN+1i*NaN;
        Tvar(2,indy)=NaN+1i*NaN;
        if all(all(T(:,:)==0))
            T(:,:)=NaN(2,nfreq);
            Tvar(:,:)=NaN(2,nfreq);
        end
    end
end
% Calculate missing impedances, apparent resistivities and phases
if all(all(all(isnan(Z))))
    [Z,Zvar]=calc_Z(Rhoa,Rhoaerr,Phs,Phserr,f);
    zrot=rhorot;
end;
if all(all(all(isnan(Rhoa)))) & all(all(all(isnan(Phs)))) 
    Z=4*pi*10^-4*Z;
    Zvar=4*pi*10^-4*Zvar;
    [Rhoa,Rhoaerr,Phs,Phserr]=calc_MT(Z,Zvar,f);
    Z=Z./(4*pi*10^-4);
    Zvar=Zvar./(4*pi*10^-4);
    rhorot=zrot;
end

end

function [nfreq] = find_nfreq(tline)
[tmp,nfreq]=strtok(tline,'//');
ind=strfind(nfreq,'/');
nfreq(ind)=[];
nfreq=str2num(nfreq);

end
