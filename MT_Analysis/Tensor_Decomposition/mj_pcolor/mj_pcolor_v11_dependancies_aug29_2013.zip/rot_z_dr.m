
%=======================================================================
function [Z,Zvar]=rot_z_dr(Z,Zvar,nfreq,theta_el)
%=======================================================================
% rotates impedances w/ errors as found in edi file
% theta is in degrees (positive is clockwise)
% Version modified to handle the Z format used by Dennis Rippe

if length(theta_el) == 1
    theta_el=ones(nfreq).*theta_el;
end

c = cosd(theta_el);      s = sind(theta_el);

for ifreq = 1:nfreq
    
    R = [ c(ifreq), -s(ifreq) ; s(ifreq), c(ifreq)];    
    RT = [ c(ifreq), s(ifreq) ; -s(ifreq), c(ifreq)];
    
    Z(:,:,ifreq) = RT*squeeze(Z(:,:,ifreq))*R;
    
end

% Leave errors unchanged. Fix later.
%dz = (U.^2*dz.^2).^.5;
%dz = abs(U*dz);
end

